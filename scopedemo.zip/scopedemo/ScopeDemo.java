import java.util.Scanner;

// Write a small program to read an integer from the keyboard
// (using Scanner) and print out the times table for that number.
// The table should run from 1 to 12.
//
// You are allowed to use one variable called scanner for your
// Scanner instance. You can use as many other variables as you
// need, but they must must all be called x. That includes any
// class instances and loop control variables that you may decide
// to use.
//
// If you use a class, the class can be called X (capital), but
// any instances of it must be called x (lower case).
//
// Any methods you create must also be called x.
//
// Optional Extra:
// Change your program so that ALL variables (including the scanner
// instance) are called x.
public class ScopeDemo {
    public static void main(String[] args) {

        X x = new X(new Scanner(System.in));
        x.x();

    }
}

//output
//Please enter a number:
//        2
//        1 times 2 equals 2
//        2 times 2 equals 4
//        3 times 2 equals 6
//        4 times 2 equals 8
//        5 times 2 equals 10
//        6 times 2 equals 12
//        7 times 2 equals 14
//        8 times 2 equals 16
//        9 times 2 equals 18
//        10 times 2 equals 20
//        11 times 2 equals 22
//        12 times 2 equals 24